#!/bin/sh

java -classpath fdt.jar:. lia.util.net.copy.FDT -preFilters PreZipFilter -c localhost $@ 
