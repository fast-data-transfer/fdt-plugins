#!/bin/sh

java -classpath fdt.jar:. lia.util.net.copy.FDT -postFilters PostZipFilter $@
