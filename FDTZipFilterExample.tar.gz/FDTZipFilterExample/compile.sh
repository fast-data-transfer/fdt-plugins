#!/bin/sh

javac -classpath fdt.jar *.java
